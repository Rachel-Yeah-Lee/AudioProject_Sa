﻿using BlankApp2.Views;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace BlankApp2.ViewModels
{
    public class MainPageViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public Command ToStory { get; set; }
        public Command ToClub { get; set; }
        public Command ToMyPage { get; set; }
        public MainPageViewModel()
        {
            ToStory = new Command(() => {
                Page1 storyPage = new Page1();
                Application.Current.MainPage.Navigation.PushAsync(storyPage);
            });
            ToClub = new Command(() =>
            {
                club c = new club();
                Application.Current.MainPage.Navigation.PushAsync(c);
            });
            ToMyPage = new Command(() =>
            {
                mypage mypage = new mypage();
                Application.Current.MainPage.Navigation.PushAsync(mypage);
            });
        }
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            throw new NotImplementedException();
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            throw new NotImplementedException();
        }

    }
}
