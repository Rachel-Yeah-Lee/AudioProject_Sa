﻿using BlankApp2.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Xamarin.Forms;

namespace BlankApp2.ViewModels
{
    class clubViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public Command ToSearchClub { get; set; }
        public Command ToMyClub { get; set; }
        public clubViewModel()
        {
            ToSearchClub = new Command(() =>
            {
                Application.Current.MainPage.Navigation.PushAsync(new SearchClub());
            });
            ToMyClub = new Command(() =>
            {
                Application.Current.MainPage.Navigation.PushAsync(new myclub());
            });
        }
    }
}
