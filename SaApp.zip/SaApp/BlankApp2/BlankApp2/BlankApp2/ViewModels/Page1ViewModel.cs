﻿using BlankApp2.Views;
using Newtonsoft.Json;
using Prism.Navigation.Xaml;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;


namespace BlankApp2.ViewModels
{
    class Page1ViewModel : INotifyPropertyChanged
    {
        private IAudioService audioService = DependencyService.Get<IAudioService>();
        public event PropertyChangedEventHandler PropertyChanged;
        public string storyEdit { get; set; }
        public string SelectedName { get; set; }
        public Command startRecording { get; set; }
        public Command endRecording { get; set; }
        public Command endPlayback { get; set; }
        public Command startPlayback { get; set; }
        public Command refreshBtn { get; set; }
        public Command SelectedNameChangedCommand { get; set; }
        public ObservableCollection<string> AudioNames { get; set; }
        public Page1ViewModel()
        {

            AudioNames = new ObservableCollection<string>();
            startRecording = new Command(async () => await startRecordAsync());
            refreshBtn = new Command(refreshCommandAsync);
            endRecording = new Command(async () => endRecord());
            endPlayback = new Command(endPlaybackAsync);
            startPlayback = new Command(async () => await startPlaybackAsync());
            SelectedNameChangedCommand = new Command(SelectedChangedCommandAsync);


        }

        private async void SelectedChangedCommandAsync()
        {
            await audioService.startPlay(SelectedName);
            tea TeaPage = new tea();
            Application.Current.MainPage.Navigation.PushAsync(TeaPage);
        }

        private async Task startPlaybackAsync()
        {
            //await audioService.startPlay(SelectedName);
        }

        private void endPlaybackAsync()
        {
            audioService.endPlay();
            //SelectedName = "";
        }

        private async Task endRecord()
        {
            await audioService.endRecord(storyEdit);
            storyEdit = string.Empty;
        }

        private async Task startRecordAsync()
        {
            await audioService.startRecord();
        }
        private async void refreshCommandAsync()
        {
            AudioNames.Clear();
            //string Url = "http://140.138.229.105/myAudioService/audioService/GetAudioNames";
            string Url = "http://ec2-3-84-69-164.compute-1.amazonaws.com/audioService/GetAudioNames";
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    HttpResponseMessage response = client.GetAsync(Url).Result;
                    List<string> names = JsonConvert.DeserializeObject<List<string>>(await response.Content.ReadAsStringAsync());
                    foreach (string name in names)
                    {
                        AudioNames.Add(name);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
    }
}
