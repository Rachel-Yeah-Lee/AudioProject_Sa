﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace BlankApp2.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class mypage : ContentPage
	{
		public mypage ()
		{
			InitializeComponent ();
		}
        async void home_click(object sender, EventArgs args)
        {

            await Navigation.PushAsync(new myfriend());


        }
        async void mf(object sender, EventArgs args)
        {

            await Navigation.PushAsync(new myfriend());


        }
        async void mc(object sender, EventArgs args)
        {

            await Navigation.PushAsync(new myclub());


        }
        async void mact(object sender, EventArgs args)
        {

            await Navigation.PushAsync(new myact());


        }
        async void mst(object sender, EventArgs args)
        {

            await Navigation.PushAsync(new mystory());


        }
    }
}