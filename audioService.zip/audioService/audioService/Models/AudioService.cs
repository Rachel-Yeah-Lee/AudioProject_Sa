﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;

namespace audioService.Models
{
    public class AudioService
    {
        private readonly object Response;

        private string GetDBConnectionString()
        {
            return
                System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString.ToString();
        }
        public void SaveAudio(Stream audio_stream)
        {
            using (BinaryReader br = new BinaryReader(audio_stream))
            {
                byte[] bytes = br.ReadBytes((int)audio_stream.Length);
                string cmdStr = "INSERT INTO Audio([Audio_Record])VALUES(@Audio_Record)";
                using (SqlConnection conn = new SqlConnection(GetDBConnectionString()))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(cmdStr, conn);
                    cmd.Parameters.Add("@Audio_Record", bytes);
                    SqlTransaction Tran = conn.BeginTransaction();
                    cmd.Transaction = Tran;
                    try
                    {
                        cmd.ExecuteScalar();      //**BookID可以用來跳到編輯頁面
                        Tran.Commit();
                    }
                    catch (Exception)
                    {
                        Tran.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }
        public void SaveAudio(Audio input_audio)
        {
            using (BinaryReader br = new BinaryReader(input_audio.Audio_Stream.InputStream))
            {
                byte[] bytes = br.ReadBytes((int)input_audio.Audio_Stream.InputStream.Length);
                string cmdStr = "INSERT INTO Audio([Audio_Record])VALUES(@Audio_Record)";
                using (SqlConnection conn = new SqlConnection(GetDBConnectionString()))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(cmdStr, conn);
                    cmd.Parameters.Add("@Audio_Record", bytes);
                    SqlTransaction Tran = conn.BeginTransaction();
                    cmd.Transaction = Tran;
                    try
                    {
                        cmd.ExecuteScalar();      //**BookID可以用來跳到編輯頁面
                        Tran.Commit();
                    }
                    catch (Exception)
                    {
                        Tran.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }
        //public void DownloadAudio()
        //{
        //    int id = 1;
        //    byte[] bytes;
        //    string contentType;
        //    string id_2;
        //    using (SqlConnection con = new SqlConnection(GetDBConnectionString()))
        //    {
        //        using (SqlCommand cmd = new SqlCommand())
        //        {
        //            cmd.CommandText = "select ID, Audio_Record from Audio where ID=@Id";
        //            cmd.Parameters.AddWithValue("@Id", id);
        //            cmd.Connection = con;
        //            con.Open();
        //            SqlDataReader sdr = cmd.ExecuteReader();
        //            sdr.Read();
        //            id_2 = sdr["Audio_Record"].ToString();
        //            bytes = (byte[])sdr["Audio_Record"];
        //            con.Close();

        //        }
        //    }
        //    HttpContext.Current.Response.Clear();
        //    HttpContext.Current.Response.Buffer = true;
        //    HttpContext.Current.Response.AppendHeader("Content-Disposition", "attachment; filename=" + "[AudioName]");
        //    HttpContext.Current.Response.ContentType = "audio/*";
        //    HttpContext.Current.Response.BinaryWrite(bytes);
        //    HttpContext.Current.Response.Flush();
        //    HttpContext.Current.Response.End();
        //}
        public byte[] GetFile(int Id)
        {
            byte[] bytes;
            using (SqlConnection con = new SqlConnection(GetDBConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select ID, Audio_Record from Audio where ID=@Id";
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.Connection = con;
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    bytes = (byte[])sdr["Audio_Record"];
                    con.Close();
                }
            }
            return bytes;
        }
    }
}