﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
namespace audioService.Models
{
    public class AudioService
    {
        private readonly object Response;

        private string GetDBConnectionString()
        {
            return
                System.Configuration.ConfigurationManager.ConnectionStrings["DBConn"].ConnectionString.ToString();
        }
        private string GetMySQLConnectionString()
        {
            return
                "Server=localhost;Database=audiodb;Uid=root;Pwd=mysql;";
        }
        public void SaveAudioToMySql(Stream audio_stream,string audio_name)
        {
            using (BinaryReader br = new BinaryReader(audio_stream))
            {
                byte[] bytes = br.ReadBytes((int)audio_stream.Length);
                string cmdStr = "INSERT INTO audiodata(Audio_Name,Audio_Record) VALUES(@Audio_Name,@Audio_Record)";
                using (MySqlConnection conn = new MySqlConnection(GetMySQLConnectionString()))
                {
                    conn.Open();
                    MySqlCommand cmd = new MySqlCommand(cmdStr, conn);
                    cmd.Parameters.Add("@Audio_Name", MySqlDbType.String).Value = audio_name;
                    cmd.Parameters.Add("@Audio_Record", MySqlDbType.Blob).Value = bytes;
                    MySqlTransaction Tran = conn.BeginTransaction();
                    cmd.Transaction = Tran;
                    try
                    {
                        cmd.ExecuteScalar();      //**BookID可以用來跳到編輯頁面
                        Tran.Commit();
                    }
                    catch (Exception e)
                    {
                        Tran.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }

            }
        }
        public void SaveAudio(Stream audio_stream)
        {
            using (BinaryReader br = new BinaryReader(audio_stream))
            {
                byte[] bytes = br.ReadBytes((int)audio_stream.Length);
                string cmdStr = "INSERT INTO Audio([Audio_Record])VALUES(@Audio_Record)";
                using (SqlConnection conn = new SqlConnection(GetDBConnectionString()))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(cmdStr, conn);
                    cmd.Parameters.Add("@Audio_Record", bytes);
                    SqlTransaction Tran = conn.BeginTransaction();
                    cmd.Transaction = Tran;
                    try
                    {
                        cmd.ExecuteScalar();      //**BookID可以用來跳到編輯頁面
                        Tran.Commit();
                    }
                    catch (Exception)
                    {
                        Tran.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }
       
        /// <summary>
        /// 從MySql取得最後一筆Audio的byte array資料
        /// </summary>
        /// <returns></returns>
        public Audio GetFileFromMySql(string audio_name)
        {
            Audio audio = new Audio();
            using (MySqlConnection con = new MySqlConnection(GetMySQLConnectionString()))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    //cmd.CommandText = "select ID, Audio_Record from audiodb.audiodata order by ID desc limit 1";
                    cmd.CommandText = @"select Audio_Name, Audio_Record 
                                        from audiodb.audiodata
                                        where Audio_Name = @audio_name
                                        order by ID desc limit 1";
                    cmd.Connection = con;
                    cmd.Parameters.Add("@audio_name", MySqlDbType.String).Value = audio_name;
                    con.Open();
                    MySqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    audio.Audio_Name = sdr["Audio_Name"].ToString();
                    audio.Audio_Record = (byte[])sdr["Audio_Record"];
                    con.Close();
                }
            }
            return audio;
        }
        /// <summary>
        /// 從sql server取得Audio的byte array資料
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public byte[] GetFile(int Id)
        {
            byte[] bytes;
            using (SqlConnection con = new SqlConnection(GetDBConnectionString()))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.CommandText = "select ID, Audio_Record from Audio where ID=@Id";
                    cmd.Parameters.AddWithValue("@Id", Id);
                    cmd.Connection = con;
                    con.Open();
                    SqlDataReader sdr = cmd.ExecuteReader();
                    sdr.Read();
                    bytes = (byte[])sdr["Audio_Record"];
                    con.Close();
                }
            }
            return bytes;
        }

        public List<string> GetNames()
        {
            List<string> names = new List<string>();
            using (MySqlConnection con = new MySqlConnection(GetMySQLConnectionString()))
            {
                using (MySqlCommand cmd = new MySqlCommand())
                {
                    cmd.CommandText = "select Audio_Name from audiodb.audiodata";
                    cmd.Connection = con;
                    con.Open();
                    MySqlDataReader sdr = cmd.ExecuteReader();
                    while (sdr.Read())
                    {
                        names.Add(sdr.GetString(0));
                    }
                    con.Close();
                }
            }
            return names;
        }
    }
}