﻿using System;
using System.IO;
using System.Web;

namespace audioService.Models
{
    public class Audio
    {
        public string Audio_Name { get; set; }
        public byte[] Audio_Record { get; set; }
    }
}