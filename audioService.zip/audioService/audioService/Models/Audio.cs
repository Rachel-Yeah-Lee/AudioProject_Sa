﻿using System;
using System.IO;
using System.Web;

namespace audioService.Models
{
    public class Audio
    {
        private char Id { get; set; }
        public HttpPostedFileWrapper Audio_Stream { get; set; }
    }
}