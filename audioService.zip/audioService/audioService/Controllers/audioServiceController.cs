﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace audioService.Controllers
{
    public class audioServiceController : Controller
    {
        // GET: audioService
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult Index(Models.Audio music)
        {
            Models.AudioService uploadAudio = new Models.AudioService();
            uploadAudio.SaveAudio(music);
            return Json(true);
        }
        //[HttpPost]
        //public JsonResult Upload(Models.Audio music)
        //{
        //    Models.AudioService uploadAudio = new Models.AudioService();
        //    uploadAudio.SaveAudio(music);
        //    return Json(true);
        //}
        [HttpPost]
        public JsonResult Upload()
        {
            try
            {
                var file = Request.Files.Count > 0 ? Request.Files[0] : null;
                Stream stream_output = file.InputStream;
                Response.AppendToLog("hi there ");
                Models.AudioService uploadAudio = new Models.AudioService();
                uploadAudio.SaveAudio(stream_output);
                return Json(true);
            }
            catch (Exception ex)
            {

                string error = ex.ToString();
                Response.AppendToLog("Error:" + error);
                return Json(error);
            }
        }
        //[HttpGet]
        //public void DownloadAudio()
        //{
        //    Models.AudioService downloadAudio = new Models.AudioService();
        //    downloadAudio.DownloadAudio();

        //}
        [HttpPost]
        public JsonResult UploadString(string str)
        {
            int a = Convert.ToInt32(str);
            Response.AppendToLog("strrrrrrrrr : " + a.ToString());
            return Json(a);
        }
        [HttpGet]
        public ActionResult Download()
        {
            int Id = int.Parse(Request.QueryString["Id"]);
            
            Models.AudioService audioService = new Models.AudioService();
            byte[] fileBytes = audioService.GetFile(Id);
            string fileName = "myfile.mp3";
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
    }
}