﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace audioService.Controllers
{
    public class audioServiceController : Controller
    {
        // GET: audioService
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public JsonResult Index(Models.Audio music)
        {
            Models.AudioService uploadAudio = new Models.AudioService();
            //uploadAudio.SaveAudioToMySql(music.Audio_Stream.InputStream);
            return Json(true);
        }
       
        [HttpPost]
        public JsonResult UploadToMySQL()
        {
            try
            {
                //string str = Request.RequestContext
                string audio_name = Request.Params.Get("Audio_Name");

                var file = Request.Files.Count > 0 ? Request.Files[0] : null;
                Stream stream_output = file.InputStream;
                Response.AppendToLog("hi there ");
                Models.AudioService uploadAudio = new Models.AudioService();
                uploadAudio.SaveAudioToMySql(stream_output,audio_name);
                return Json(true);
            }
            catch (Exception ex)
            {

                string error = ex.ToString();
                Response.AppendToLog("Error:" + error);
                return Json(error);
            }
        }
        [HttpPost]
        public JsonResult Upload()
        {
            try
            {
                var file = Request.Files.Count > 0 ? Request.Files[0] : null;
                Stream stream_output = file.InputStream;
                Response.AppendToLog("hi there ");
                Models.AudioService uploadAudio = new Models.AudioService();
                uploadAudio.SaveAudio(stream_output);
                return Json(true);
            }
            catch (Exception ex)
            {

                string error = ex.ToString();
                Response.AppendToLog("Error:" + error);
                return Json(error);
            }
        }
        //[HttpGet]
        //public void DownloadAudio()
        //{
        //    Models.AudioService downloadAudio = new Models.AudioService();
        //    downloadAudio.DownloadAudio();

        //}
        /// <summary>
        /// 取得所有檔案名稱(Audio_Name)
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public JsonResult GetAudioNames()
        {
            Models.AudioService audioService = new Models.AudioService();
            return Json(audioService.GetNames(),JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// 用檔案名稱找音檔
        /// </summary>
        /// <param name="audio_name"></param>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Download(string audio_name)
        {
            Models.Audio audio = new Models.Audio();
            //int Id = int.Parse(Request.QueryString["Id"]);
            Models.AudioService audioService = new Models.AudioService();
            audio = audioService.GetFileFromMySql(audio_name);
            string fileName = audio.Audio_Name + ".mp3";
            return File(audio.Audio_Record, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
    }
}