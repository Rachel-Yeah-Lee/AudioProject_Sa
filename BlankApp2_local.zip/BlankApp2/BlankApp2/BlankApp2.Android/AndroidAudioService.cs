﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Media;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using BlankApp2.Droid;
using BlankApp2.ViewModels;
using Stream = Android.Media.Stream;
using Android.Support.V4.App;
using Android;
using Android.Content.PM;
using Enviroment = Android.OS.Environment;

[assembly: UsesPermission(Manifest.Permission.RecordAudio)]
[assembly: UsesPermission(Manifest.Permission.WriteExternalStorage)]
[assembly: Xamarin.Forms.Dependency(typeof(AndroidAudioService))]
namespace BlankApp2.Droid
{
    class AndroidAudioService : IAudioService
    {
        static AudioManager audioManager = null;
        string filePath = "/data/data/com.companyname.appname/files/testAudio.mp4";
        static MediaPlayer player = null;
        MediaRecorder recorder = null;
        /// <summary>
        /// 啟動MediaRecorder開始錄音
        /// </summary>
        /// <returns></returns>
        public async Task startRecord()
        {
            try
            {
                //Java.IO.File sdDir = Android.OS.Environment.GetExternalStoragePublicDirectory(Android.OS.Environment.DirectoryMusic);
                //filePath = sdDir + "/" + "testAudio.mp3";
                if (File.Exists(filePath))
                    File.Delete(filePath);

                //Java.IO.File myFile = new Java.IO.File(filePath);
                //myFile.CreateNewFile();

                if (recorder == null)
                    recorder = new MediaRecorder(); // Initial state.
                else

                    recorder.Reset();
                //AudioManager.IOnAudioFocusChangeListener listener = null;
                //var ret = audioManager.RequestAudioFocus(listener, Stream.Music, AudioFocus.Gain);

                recorder.SetAudioSource(AudioSource.Mic);
                recorder.SetOutputFormat(OutputFormat.Mpeg4);
                recorder.SetAudioEncoder(AudioEncoder.AmrNb); // Initialized state.
                recorder.SetOutputFile(filePath); // DataSourceConfigured state.
                recorder.Prepare(); // Prepared state
                recorder.Start(); // Recording state.


            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(ex.StackTrace);
            }
        }
        /// <summary>
        /// 啟動MediaPlayer開始播放
        /// </summary>
        /// <returns></returns>
        public async Task startPlay()
        {
            try
            {
                if (player == null)
                {
                    player = new MediaPlayer();
                }
                else
                {
                    player.Reset();
                }

                // This method works better than setting the file path in SetDataSource. Don't know why.
                Java.IO.File file = new Java.IO.File(filePath);
                Java.IO.FileInputStream fis = new Java.IO.FileInputStream(file);
                await player.SetDataSourceAsync(fis.FD);

                //player.SetDataSource(filePath);
                player.Prepare();
                player.Start();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(ex.StackTrace);
            }
        }
        /// <summary>
        /// 釋放MediaRecorder結束錄音
        /// </summary>
        public void endRecord()
        {
            if (recorder != null)
            {
                recorder.Stop();
                recorder.Release();
                recorder = null;
            }
        }
        /// <summary>
        /// 釋放MediaPlayer結束播放
        /// </summary>
        public void endPlay()
        {
            if ((player != null))
            {
                if (player.IsPlaying)
                {
                    player.Stop();
                }
                player.Release();
                player = null;
            }
        }
    }
}