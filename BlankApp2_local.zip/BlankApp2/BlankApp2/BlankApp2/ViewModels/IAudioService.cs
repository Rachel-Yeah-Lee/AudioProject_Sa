﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace BlankApp2.ViewModels
{
    public interface IAudioService
    {
        Task startRecord();
        void endRecord();
        Task startPlay();
        void endPlay();
    }
}
