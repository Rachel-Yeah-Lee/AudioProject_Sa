﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace BlankApp2.ViewModels
{
    public class MainPageViewModel : INotifyPropertyChanged
    {
        private IAudioService audioService = DependencyService.Get<IAudioService>();

        public event PropertyChangedEventHandler PropertyChanged;

        public DelegateCommand startRecordingBtn { get; set; }
        public DelegateCommand endRecordingBtn { get; set; }
        public DelegateCommand startPlaybackBtn { get; set; }
        public DelegateCommand endPlaybackBtn { get; set; }
        public Command testBtn { get; set; }
        public string testLable { get; set; }
        //public event PropertyChangedEventHandler PropertyChanged;
        //public MainPageViewModel()
        //{
        //    startRecordingBtn = new DelegateCommand(async () => await startRecordAsync(),conExecute);
        //    endRecordingBtn = new DelegateCommand(endRecord);
        //    startPlaybackBtn = new DelegateCommand(async () => await startPlaybackAsync());
        //    endPlaybackBtn = new DelegateCommand(endPlayback);
        //    testBtn = new Command(testAction);
        //}
        public MainPageViewModel()
        {
            startRecordingBtn = new DelegateCommand(async () => await startRecordAsync(), conExecute);
            endRecordingBtn = new DelegateCommand(endRecord,conExecute2);
            startPlaybackBtn = new DelegateCommand(async () => await startPlaybackAsync());
            endPlaybackBtn = new DelegateCommand(endPlayback);
            testBtn = new Command(testAction);
        }

        private bool conExecute2()
        {
            return true;
        }

        private void testAction()
        {
            testLable = "invoke!!!!!!!!!";
        }

        private bool conExecute()
        {
            return true;
        }

        private void endPlayback()
        {
            audioService.endPlay();
        }

        private async Task startPlaybackAsync()
        {
            await audioService.startPlay();
        }

        private void endRecord()
        {
            audioService.endRecord();
        }

        private async Task startRecordAsync()
        {
            await audioService.startRecord();
        }

        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            throw new NotImplementedException();
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            throw new NotImplementedException();
        }

    }
}
