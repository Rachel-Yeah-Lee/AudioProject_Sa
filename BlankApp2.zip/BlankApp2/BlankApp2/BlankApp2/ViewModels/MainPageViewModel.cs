﻿using BlankApp2.Views;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Navigation;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace BlankApp2.ViewModels
{
    public class MainPageViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public Command ToStory { get; set; }
        public Command ToTea { get; set; }
        public MainPageViewModel()
        {
            ToStory = new Command(() => {
                Page1 storyPage = new Page1();
                Application.Current.MainPage.Navigation.PushAsync(storyPage);
            });
            ToTea = new Command(() =>
            {
                tea teaPage = new tea();
                Application.Current.MainPage.Navigation.PushAsync(teaPage);
            });
        }
        public void OnNavigatedFrom(INavigationParameters parameters)
        {
            throw new NotImplementedException();
        }

        public void OnNavigatedTo(INavigationParameters parameters)
        {
            throw new NotImplementedException();
        }

    }
}
