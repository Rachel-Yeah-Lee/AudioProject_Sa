﻿using System;
using System.Net.Http;
using System.IO;
using System.Threading.Tasks;
using Android.App;
using Android.Media;
using BlankApp2.Droid;
using BlankApp2.ViewModels;
using Android;
using Stream = System.IO.Stream;
using Xamarin.Android.Net;
using System.Net.Http.Headers;

[assembly: UsesPermission(Manifest.Permission.RecordAudio)]
[assembly: UsesPermission(Manifest.Permission.WriteExternalStorage)]
[assembly: Xamarin.Forms.Dependency(typeof(AndroidAudioService))]
namespace BlankApp2.Droid
{
    class AndroidAudioService : IAudioService
    {
        static string DownloadServiceUrl = "http://192.168.1.105/myAudioService/audioService/Download";
        static string UploadServiceUrl = "http://192.168.1.105/myAudioService/audioService/Upload";
        static AudioManager audioManager = null;
        string filePath = "/data/data/com.companyname.appname/files/testAudio.mp4";
        static MediaPlayer player = null;
        MediaRecorder recorder = null;
        /// <summary>
        /// 啟動MediaRecorder開始錄音
        /// </summary>
        /// <returns></returns>
        public async Task startRecord()
        {
            try
            {
                if (File.Exists(filePath))
                    File.Delete(filePath);

                if (recorder == null)
                    recorder = new MediaRecorder(); // Initial state.
                else

                    recorder.Reset();

                recorder.SetAudioSource(AudioSource.Mic);
                recorder.SetOutputFormat(OutputFormat.Mpeg4);
                recorder.SetAudioEncoder(AudioEncoder.AmrNb); // Initialized state.
                recorder.SetOutputFile(filePath); // DataSourceConfigured state.
                recorder.Prepare(); // Prepared state
                recorder.Start(); // Recording state.
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(ex.StackTrace);
            }
        }
        /// <summary>
        /// 啟動MediaPlayer開始播放
        /// </summary>
        /// <returns></returns>
        public async Task startPlay()
        {
            try
            {
                if (player == null)
                {
                    player = new MediaPlayer();
                }
                else
                {
                    player.Reset();
                }
                using (HttpClient client = new HttpClient())
                {
                    try
                    {
                        string Audio_Id="11";
                        string Url = DownloadServiceUrl + Audio_Id;
                        //var requestTask = client.GetAsync(url);
                        //HttpResponseMessage response = await Task.Run(() => requestTask);
                        HttpResponseMessage response = await client.GetAsync(Url);
                        using (Stream streamToReadFrom = await response.Content.ReadAsStreamAsync())
                        {
                            string fileToWriteTo = Path.GetTempFileName();
                            using (Stream streamToWriteTo = File.Open(fileToWriteTo, FileMode.Create))
                            {
                                await streamToReadFrom.CopyToAsync(streamToWriteTo);
                            }
                            Java.IO.File file = new Java.IO.File(fileToWriteTo);
                            Java.IO.FileInputStream fis = new Java.IO.FileInputStream(file);
                            await player.SetDataSourceAsync(fis.FD);
                        }
                    }
                    catch (Exception e)
                    {
                    }
                }
                // This method works better than setting the file path in SetDataSource. Don't know why.
                // await player.SetDataSource(filePath);
                player.Prepare();
                player.Start();
            }
            catch (Exception ex)
            {
                Console.Out.WriteLine(ex.StackTrace);
            }
        }
        /// <summary>
        /// 釋放MediaRecorder結束錄音
        /// </summary>
        public async Task endRecord()
        {
            if (recorder != null)
            {
                recorder.Stop();
                recorder.Release();
                recorder = null;
            }
            //FileStream file = File.OpenRead(filePath);
            var fs = File.Open(filePath, FileMode.Open);
            //Audio audio = new Audio();
            //audio.Record_Audio = file;
            HttpClient client = new HttpClient();
            HttpContent httpContent = new StreamContent(fs);
            using (var formData = new MultipartFormDataContent())
            {
                httpContent.Headers.Add("Content-Disposition", "form-data; name=\"files\"; filename=\"" + "MyAudio.mp4" + "\"");
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                httpContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                formData.Add(httpContent, "stream",filePath);
                try
                {
                    
                    HttpResponseMessage response = client.PostAsync(UploadServiceUrl, formData).GetAwaiter().GetResult();
                }
                catch (Exception e)
                {
                    throw e;
                }
                fs.Close();
            }


        }
        /// <summary>
        /// 釋放MediaPlayer結束播放
        /// </summary>
        public void endPlay()
        {
            if ((player != null))
            {
                if (player.IsPlaying)
                {
                    player.Stop();
                }
                player.Release();
                player = null;
            }
        }

    }
}